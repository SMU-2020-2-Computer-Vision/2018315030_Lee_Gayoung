import os
import cv2
import numpy as np
from matplotlib import pyplot as plt


os.chdir(os.path.dirname(os.path.abspath(__file__)))

img_rgb = cv2.imread('test_background.png')
template = cv2.imread('fish.png.',0)
img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)


# template matching
w, h = template.shape[::-1] 
res = cv2.matchTemplate(img_gray, template, cv2.TM_CCOEFF_NORMED)
#min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
# x,y = minLoc
# w,h = template.shape
img_res = img_rgb.copy()

# Thresholding
threshold = 0.3
loc = np.where(res >= threshold)


img_res = img_rgb.copy()
for pt in zip(*loc[::-1]):   
    #cv2.rectangle(img_res, (x,y), (x+w, y+h), (0,0,255), 1)
    cv2.rectangle(img_res, pt, (pt[0] + w, pt[1] + h), (0,0,255), 2)

# result = template_matching()
# print(result)

titles = ['Original', 'Template Matching']
images = [img_rgb, img_res]

for i in range(2):
    plt.subplot(1, 2, i+1)
    plt.imshow(cv2.cvtColor(images[i], cv2.COLOR_BGR2RGB))    
    plt.title(titles[i])
    plt.xticks([]), plt.yticks([])
plt.show()


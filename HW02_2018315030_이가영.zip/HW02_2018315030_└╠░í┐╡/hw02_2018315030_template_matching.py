import os
import cv2
import numpy as np
from matplotlib import pyplot as plt


def template_matching(img_template, img_reference)

    #rotat = cv2.getRotationMatrix2D(center, angle, scale)
    x, y, angle, scale = template_matching(img_template, img_reference)
    
    return 





